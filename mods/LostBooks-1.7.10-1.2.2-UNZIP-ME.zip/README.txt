To install, place the mods and config folders into your .minecraft folder.

The config folder also contains the default stories. If you are reinstalling (or updating), it is highly recommended to either remove your current book files (the adLib, common, unique, and words folders in config/LostBooks) or remove the default book files in config/LostBooks before reinstalling/updating the mod.

Please check out config/LostBooks/authors.txt to see all the amazing people that contributed to this mod!